package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.Order;
import entity.Product;
import entity.Type;
import entity.XiaoMi;

import util.JDBCUtil;

public class TypeDao implements ITypeDao{

	public void insertType(Type type) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="insert into type (t_id,t_name,t_price,t_disc,t_img) "
			+"values('"+type.getT_id()
			+"','"+type.getT_name()
			+"','"+type.getT_price()
			+"','"+type.getT_disc()
			+"','"+type.getT_img()+"')";
		//System.out.println(sql);
		try {
			int count=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
	}

	public List<Type> findAllTypes() {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="select * from type ";
		List<Type> list=new ArrayList<Type>();
		ResultSet rs ;
		try {
			rs=st.executeQuery(sql);
			while(rs.next()){
				Type type=new Type();
				type.setT_id(rs.getInt("t_id"));
				type.setT_name(rs.getString("t_name"));
				type.setT_price(rs.getDouble("t_price"));
				type.setT_disc(rs.getString("t_disc"));
				type.setT_img(rs.getString("t_img"));
				list.add(type);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return list;
	}

	public boolean deleteType(Type type) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="delete from type where t_id='"+type.getT_id()+"'";
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return false;
	}

	public Type findTypeById(int id) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		Type type=new Type();
		String sql="select * from type where t_id = "+id;
		try {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				type.setT_id(rs.getInt("t_id"));
				type.setT_name(rs.getString("t_name"));
				type.setT_price(rs.getDouble("t_price"));
				type.setT_disc(rs.getString("t_disc"));
				type.setT_img(rs.getString("t_img"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return type;
	}

	public boolean modifyType(Type type) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="update type set t_name='"+type.getT_name()
		+"',t_price='"+type.getT_price()
		+"',t_disc='"+type.getT_disc()
		+"',t_img='"+type.getT_img()
		+"' where t_id="+type.getT_id();
		
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return false;
	}

	
	
	
	//С��
	public boolean deleteXiaoMi(XiaoMi xiaomi) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="delete from product1 where p1_id='"+xiaomi.getId()+"'";
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		//�ر�����
		JDBCUtil.closeAll(null, st, null);
		return false;
	}

	public List<XiaoMi> findAllXiaoMi() {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		 String sql="select * from product1";
		 
		 List<XiaoMi> list=new ArrayList<XiaoMi>();
		 try {
			 ResultSet rs=st.executeQuery(sql);
			
			 while(rs.next()){
				 XiaoMi xiaomi=new XiaoMi();
				 xiaomi.setId(rs.getInt("p1_id"));
				 xiaomi.setNam(rs.getString("p1_name"));
				 xiaomi.setPrice(rs.getDouble("p1_price"));
				 xiaomi.setImg(rs.getString("p1_img"));
				 xiaomi.setSalenum(rs.getInt("p1_salenum"));
				 xiaomi.setDisc(rs.getString("p1_disc"));
				 xiaomi.setTotal(rs.getInt("p1_total"));
				list.add(xiaomi);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return list;
	}

	public XiaoMi findXiaoMiById(int id) {
		// TODO Auto-generated method stub
		XiaoMi xiaomi=new XiaoMi();
		Statement st=JDBCUtil.getStatement();
		String sql="select * from product1 where p1_id="+id;
		try {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				xiaomi.setId(rs.getInt("p1_id"));
				xiaomi.setNam(rs.getString("p1_name"));
				xiaomi.setPrice(rs.getDouble("p1_price"));
				xiaomi.setImg(rs.getString("p1_img"));
				xiaomi.setSalenum(rs.getInt("p1_salenum"));
				xiaomi.setDisc(rs.getString("p1_disc"));
				xiaomi.setTotal(rs.getInt("p1_total"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		//�ر�����
		JDBCUtil.closeAll(null, st, null);
		return xiaomi;
	}

	public void insertXiaoMi(XiaoMi xiaomi) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		System.out.println(st);
		//String sql="insert into product1 (p1_img,p1_name,p1_price,p1_id) values('"+xiaomi.getImg()+"'" +
		//				",'"+xiaomi.getNam()+"',"+xiaomi.getPrice()+","+xiaomi.getId()+")";
		
		String sql="insert into product1 (p1_img,p1_name,p1_price,p1_salenum,p1_disc,p1_total) "
		+"values('"+xiaomi.getImg()
		+"','"+xiaomi.getNam()
		+"','"+xiaomi.getPrice()
		+"','"+xiaomi.getSalenum()
		+"','"+xiaomi.getDisc()
		+"','"+xiaomi.getTotal()+"')";
		
		System.out.println(sql);
		try {
		 st.executeUpdate(sql);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		//�ر�����
		JDBCUtil.closeAll(null, st, null);
	}

	public boolean modifyXiaoMi(XiaoMi xiaomi) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="update product1 set p1_name='"+xiaomi.getNam()
		+"',p1_img='"+xiaomi.getImg()
		+"',p1_price='"+xiaomi.getPrice()
		+"',p1_salenum='"+xiaomi.getSalenum()
		+"',p1_disc='"+xiaomi.getDisc()
		+"',p1_total='"+xiaomi.getTotal()
		+"' where p1_id= "+xiaomi.getId();
		System.out.println(sql);
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		//�ر�����
		JDBCUtil.closeAll(null, st, null);
		return false;
	}
	
	//���붩����Ϣ
	public void insertorder() {
		// TODO Auto-generated method stub
		 System.out.println(234);
		 TypeDao typedao = new TypeDao();
		 List<Product> listp = typedao.queryshopping();//��
		 Statement st=JDBCUtil.getStatement();
		 String sql;
		 for(int i = 0 ; i < listp.size();i++){
			 sql="insert into order1 (order1_item_name,order1_item_price,order1_item_num,order1_item_totalprice,order1_username) "
					+"values('"+listp.get(i).getItemname()
					+"',"+listp.get(i).getItemprice()
					+","+listp.get(i).getNum()+","+listp.get(i).getItemprice()*listp.get(i).getNum()+",'"+listp.get(i).getUsername()+"')";
			System.out.println(sql);
			 try {
					st.executeUpdate(sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		 }
	}
   
	public List<Order> findAllOrder() {
		// TODO Auto-generated method stub
	 Statement st=JDBCUtil.getStatement();
	 String sql="select * from order1 ";
	 List<Order> list=new ArrayList<Order>();
	 ResultSet rs;
	 try {
		rs=st.executeQuery(sql);
		while(rs.next()){
			Order order=new Order();
			order.setOrder_id(rs.getInt("order1_id"));
			order.setOrder_item_name(rs.getString("order1_item_name"));
			order.setOrder_item_price(rs.getInt("order1_item_price"));
			order.setOrder_item_num(rs.getInt("order1_item_num"));
			order.setOrder_item_totalprice(rs.getInt("order1_item_price")*rs.getInt("order1_item_num"));
			order.setOrder_username(rs.getString("order1_username"));
			list.add(order);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return list;
	}

	public List<Product> queryshopping() {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		 String sql="select * from shopping";
		 
		 List<Product> list=new ArrayList<Product>();
		 try {
			 ResultSet rs=st.executeQuery(sql);
			
			 while(rs.next()){
				 Product p=new Product();
				 p.setId(rs.getInt("id"));
				 p.setItemname(rs.getString("itemname"));
				 p.setItemprice(rs.getInt("itemprice"));
				 p.setNum(rs.getInt("itemnum"));
				 p.setUsername(rs.getString("username"));
				 System.out.println(123);
				 list.add(p);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return list;
	}

}
