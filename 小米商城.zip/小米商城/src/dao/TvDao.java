package dao;

import java.sql.SQLException;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import util.JDBCUtil;
import entity.Product3;
import entity.Tv;

public class TvDao implements ITvDao{

	public void insertTV(Tv tv) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="insert into tv_product (tv_id,tv_name,tv_price,tv_disc,tv_img,tv_num) "
				+"values('"+tv.getTv_id()
				+"','"+tv.getTv_name()
				+"','"+tv.getTv_price()
				+"','"+tv.getTv_disc()
				+"','"+tv.getTv_img()
				+"','"+tv.getTv_num()+"')";
				try {
					st.executeUpdate(sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				JDBCUtil.closeAll(null, st, null);
	}

	public boolean deleteTV(Tv tv) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="delete from tv_product where tv_id='"+tv.getTv_id()+"'";
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return false;
	}

	public boolean modifyTV(Tv tv) {
		Statement st=JDBCUtil.getStatement();
		String sql="update tv_product set tv_name='"+tv.getTv_name()
		+"',tv_price='"+tv.getTv_price()
		+"',tv_disc='"+tv.getTv_disc()
		+"',tv_img='"+tv.getTv_img()
		+"',tv_num='"+tv.getTv_num()
		+"' where tv_id="+tv.getTv_id();
		//System.out.println(sql);
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		//�ر�����
		JDBCUtil.closeAll(null, st, null);
		// TODO Auto-generated method stub
		return false;	
	}

	public List<Tv> findAllTv() {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="select * from tv_product";
		List<Tv> list=new ArrayList<Tv>();
		ResultSet rs;
		try {
			rs=st.executeQuery(sql);
			while(rs.next()){
				Tv tv=new Tv();
				tv.setTv_id(rs.getInt("tv_id"));
				tv.setTv_name(rs.getString("tv_name"));
				tv.setTv_price(rs.getDouble("tv_price"));
				tv.setTv_disc(rs.getString("tv_disc"));
				tv.setTv_img(rs.getString("tv_img"));
				tv.setTv_num(rs.getInt("tv_num"));
				list.add(tv);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public Tv findTvById(int id) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		Tv tv=new Tv();
		String sql="select * from tv_product where tv_id ="+id;
		try {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				tv.setTv_id(rs.getInt("tv_id"));
				tv.setTv_name(rs.getString("tv_name"));
				tv.setTv_price(rs.getDouble("tv_price"));
				tv.setTv_disc(rs.getString("tv_disc"));
				tv.setTv_img(rs.getString("tv_img"));
				tv.setTv_num(rs.getInt("tv_num"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return tv;
	}

}
