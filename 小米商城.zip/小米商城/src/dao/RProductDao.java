package dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import util.JDBCUtil;
import entity.R_Product;
import entity.RType;
import entity.User;

public class RProductDao implements IRProduct{
	//��ȡִ��sql����
	   public Statement st;
	   public List<RType> findAllRType(){
		   st =JDBCUtil.getStatement();
	       String sql="select * from rt_type";
	  	   
	       List<RType> list=new ArrayList<RType>();
 	   try {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				
				RType rType=new RType();
				rType.setRt_id(rs.getInt("rt_id"));
				rType.setRt_name(rs.getString("rt_name"));
				
				list.add(rType);//��rType�������ӵ�list������
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JDBCUtil.closeAll(null, st, null);
		return list;
		
	   }
	   //�����Ʒ
	   public boolean insertRProduct(R_Product product) {
			st=JDBCUtil.getStatement();
			String sql="insert into r_product (r_name,price,disc,numb,discount,img,rt_id) values('"
				      +product.getR_name()+"',"
				      +product.getPrice()+",'"
				      +product.getDisc()+"',"
				      +product.getNumb()+","
				      +product.getDiscount()+",'"
				      +product.getImg()+"',"
				      +product.getRt_id()+")";
		    System.out.println(sql);
		    
		    //ִ��sql���
		    try {
				int count=st.executeUpdate(sql);
				if(count>0){
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return false;
		}

		public List<R_Product> findAllRProduct() {
			st=JDBCUtil.getStatement();
			String sql="select r_id,r_name,price,total,disc,numb,discount,img,state,rt_id,(select rt_name from rt_type where rt_type.rt_id=r_product.rt_id)rt from r_product";
			List<R_Product> list=new ArrayList<R_Product>();
			try {
				ResultSet rs=st.executeQuery(sql);
				while(rs.next()){
					R_Product p=new R_Product();
					p.setR_id(rs.getInt("r_id"));
					p.setDisc(rs.getString("disc"));
					p.setDiscount(rs.getDouble("discount"));
					p.setImg(rs.getString("img"));
					p.setNumb(rs.getInt("numb"));
					p.setR_name(rs.getString("r_name"));
					p.setPrice(rs.getDouble("price"));
					p.setState(rs.getInt("state"));
					p.setRt_id(rs.getInt("rt_id"));
					p.setTotal(rs.getInt("total"));
					p.setRt_name(rs.getString("rt"));

					list.add(p); // ����Ʒ���ӵ�������
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return list;
		}
		
	public boolean RProductUpdate(String sql) throws SQLException{
		
		st=JDBCUtil.getStatement();
		
		try {
			int rs=st.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return false;
		
		
		
	}
		
	
	
	

}
