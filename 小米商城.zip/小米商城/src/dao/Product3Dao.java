package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import util.JDBCUtil;

import entity.Product3;

public class Product3Dao implements IProduct3Dao {
	Statement st=JDBCUtil.getStatement();
    //����ʼǱ�
	public void insertProduct3(Product3 p) {
		// TODO Auto-generated method stub
		String sql="insert into product3 (laptop_id,laptop_name,laptop_price,laptop_disc,laptop_img) "
		+"values('"+p.getLaptop_id()
		+"','"+p.getLaptop_name()
		+"','"+p.getLaptop_price()
		+"','"+p.getLaptop_disc()
		+"','"+p.getLaptop_img()+"')";
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		
	}
	//ɾ���ʼǱ�
	public boolean deleteProduct3(Product3 p) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="delete from product3 where laptop_id='"+p.getLaptop_id()+"'";
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return false;
	}
    //���ұʼǱ�
	public List<Product3> findAllProduct3() {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="select * from product3";
		List<Product3> list=new ArrayList<Product3>();
		ResultSet rs;
		try {
			rs=st.executeQuery(sql);
			while(rs.next()){
				Product3 p=new Product3();
				p.setLaptop_id(rs.getInt("laptop_id"));
				p.setLaptop_name(rs.getString("laptop_name"));
				p.setLaptop_price(rs.getDouble("laptop_price"));
				p.setLaptop_disc(rs.getString("laptop_disc"));
				p.setLaptop_img(rs.getString("laptop_img"));
				list.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
    //ͨ��id���ұʼǱ�
	public Product3 findProduct3ById(int id) {
		// TODO Auto-generated method stub
		Product3 p3=new Product3();
		String sql="select * from product3 where laptop_id ="+id;
		try {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				p3.setLaptop_id(rs.getInt("laptop_id"));
				p3.setLaptop_name(rs.getString("laptop_name"));
				p3.setLaptop_price(rs.getDouble("laptop_price"));
				p3.setLaptop_disc(rs.getString("laptop_disc"));
				p3.setLaptop_img(rs.getString("laptop_img"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return p3;
	}
    //�޸ıʼǱ���Ϣ
	public boolean modifyProduct3(Product3 p) {
		// TODO Auto-generated method stub
		Statement st=JDBCUtil.getStatement();
		String sql="update product3 set laptop_name='"+p.getLaptop_name()
		+"',laptop_price='"+p.getLaptop_price()
		+"',laptop_disc='"+p.getLaptop_disc()
		+"',laptop_img='"+p.getLaptop_img()
		+"' where laptop_id="+p.getLaptop_id();
		System.out.println(sql);
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
				return true;			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		//�ر�����
		JDBCUtil.closeAll(null, st, null);
		return false;
	}
	}
	
