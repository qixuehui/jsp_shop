package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import util.JDBCUtil;
import entity.Product;
import entity.User;

public class UserDao implements IUserDao {
	   public Statement st=JDBCUtil.getStatement();

	public void insertUser(User user) {
		// TODO Auto-generated method stub
		String sql="insert into user (username,password,mobile,mailbox,role) "
			+"values('"+user.getUsername()
			+"','"+user.getPassword()
			+"','"+user.getMobile()
			+"','"+user.getMailbox()
			+"','"+user.getRole()+"')";
		//System.out.println(sql);
		try {
			int count=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		
	}

	
	
	public List<User> findAllUsers(String whereSQL) {
		// TODO Auto-generated method stub
		st=JDBCUtil.getStatement();
		String sql="select * from user "+whereSQL;
		if(whereSQL==null||whereSQL.equals("null")||whereSQL.equals("")){
		sql="select * from user "	;
		}
		List<User> list=new ArrayList<User>();
		try {
			ResultSet rs=st.executeQuery(sql);
		while(rs.next()){
		User user=new User();
		user.setId(rs.getInt("id"));
		user.setUsername(rs.getString("username"));	
		user.setPassword(rs.getString("password"));
		user.setMobile(rs.getString("mobile"));
		user.setMailbox(rs.getString("mailbox"));
		user.setRole(rs.getInt("role"));
		list.add(user);
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return list;
	}
	public User findUserById(int id){
		User user=new User();
		st=JDBCUtil.getStatement();
		String sql="select * from user where id="+id;
		try {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
			user.setId(rs.getInt("id"));
			user.setUsername(rs.getString("username"));
			user.setPassword(rs.getString("password"));
			user.setMobile(rs.getString("mobile"));
			user.setMailbox(rs.getString("mailbox"));
			user.setRole(rs.getInt("role"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return user;
	}

	public User findUserByName(String name) {
		User user=null;
		st=JDBCUtil.getStatement();
		String sql="select * from user where username='"+name+"'";
		try {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
			user=new User();
			user.setId(rs.getInt("id"));
			user.setUsername(rs.getString("username"));
			user.setPassword(rs.getString("password"));
			user.setMobile(rs.getString("mobile"));
			user.setMailbox(rs.getString("mailbox"));
			user.setRole(rs.getInt("role"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return user;
	}

	public boolean modifyUser(User user) {
		// TODO Auto-generated method stub
		st=JDBCUtil.getStatement();
		String sql="update user set username='"+user.getUsername()
		+"',password='"+user.getPassword()
		+"',mobile='"+user.getMobile()
		+"',mailbox='"+user.getMailbox()
		+"',role='"+user.getRole()
		+"' where id="+user.getId();
		//System.out.println(sql);
		try {
			int count=st.executeUpdate(sql);
			if(count>0){
			return true;	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	public boolean deleteUser(int id) {
		// TODO Auto-generated method stub
		st=JDBCUtil.getStatement();
		String sql="delete from user where id="+id;
		System.out.println(sql);
		try {
		int count=st.executeUpdate(sql);
		System.out.println(count);
		if(count>0){
			return true;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public List<User> findPageUsers(int pageSize,int pageNow,String whereSQL) {
		// TODO Auto-generated method stub
		st=JDBCUtil.getStatement();
		String sql="select * from user "+whereSQL+" limit "+pageSize*(pageNow-1)+","+pageSize;
		if(whereSQL==null||whereSQL.equals("null")||whereSQL.equals("")){
		sql="select * from user limit "+pageSize*(pageNow-1)+","+pageSize;	
		}
		System.out.println(sql);
		List<User> list=new ArrayList<User>();
		try {
			ResultSet rs=st.executeQuery(sql);
		while(rs.next()){
		User user=new User();
		user.setId(rs.getInt("id"));
		user.setUsername(rs.getString("username"));	
		user.setPassword(rs.getString("password"));
		user.setMobile(rs.getString("mobile"));
		user.setMailbox(rs.getString("mailbox"));
		user.setRole(rs.getInt("role"));
		list.add(user);
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);
		return list;
	}
	
	public List<Product> FindAllProduct(String whereSQL){
		st = JDBCUtil.getStatement();	
		String sql = "select * from shopping"+whereSQL;
		List<Product> list = new ArrayList<Product>();
		if(whereSQL == null||whereSQL.equals("null")||whereSQL.equals("")){
			sql = "select * from shopping";
		}
		try {
			//System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setItemname(rs.getString("itemname"));
				product.setItemprice(rs.getInt("itemprice"));
				product.setUsername(rs.getString("username"));
				list.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JDBCUtil.closeAll(null, st, null);	
		return list;
	
	}
	public boolean DeleteProduct(Product product){
		st = JDBCUtil.getStatement();
		String sql = "delete from shopping where id = '"+product.getId()+"'";
		try {
			int count = st.executeUpdate(sql);
			if(count > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return false;
	}
	public boolean AddProduct(Product product){//���ﳵ�������Ʒ
		st = JDBCUtil.getStatement();
		String sql = "insert into shopping (itemname,itemprice,username,itemnum) values ('"+product.getItemname()+"','"+product.getItemprice()+"','"+product.getUsername()+"','"+product.getNum()+"')";
		try {
			int count = st.executeUpdate(sql);
			if(count > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return false;
	}
	public Product findshopByName(String itemname){
		return null;
		
	}



}
