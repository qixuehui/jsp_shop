package entity;

public class R_Product {

	 private int r_id;
	 private String r_name;
	 private double price;
	 private int total;
	 private String disc;
	 private int numb;
	 private double discount;
	 private String img;
	 private int state;
	 private int rt_id;
	 private String rt_name; 
	public int getR_id() {
		return r_id;
	}
	public void setR_id(int rId) {
		r_id = rId;
	}
	public String getR_name() {
		return r_name;
	}
	public void setR_name(String rName) {
		r_name = rName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getDisc() {
		return disc;
	}
	public void setDisc(String disc) {
		this.disc = disc;
	}
	public int getNumb() {
		return numb;
	}
	public void setNumb(int numb) {
		this.numb = numb;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getRt_id() {
		return rt_id;
	}
	public void setRt_id(int rtId) {
		rt_id = rtId;
	}
	public String getRt_name() {
		return rt_name;
	}
	public void setRt_name(String rtName) {
		rt_name = rtName;
	}
	 
	   
}
