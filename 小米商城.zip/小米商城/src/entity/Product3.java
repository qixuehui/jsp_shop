package entity;

public class Product3 {
	private int laptop_id;
	private String laptop_name;
	private double laptop_price;
	private String laptop_disc;
	private String laptop_img;
	
	public int getLaptop_id() {
		return laptop_id;
	}
	public void setLaptop_id(int laptopId) {
		laptop_id = laptopId;
	}
	public String getLaptop_name() {
		return laptop_name;
	}
	public void setLaptop_name(String laptopName) {
		laptop_name = laptopName;
	}
	public double getLaptop_price() {
		return laptop_price;
	}
	public void setLaptop_price(double laptopPrice) {
		laptop_price = laptopPrice;
	}
	public String getLaptop_disc() {
		return laptop_disc;
	}
	public void setLaptop_disc(String laptopDisc) {
		laptop_disc = laptopDisc;
	}
	public String getLaptop_img() {
		return laptop_img;
	}
	public void setLaptop_img(String laptopImg) {
		laptop_img = laptopImg;
	}
	

}
