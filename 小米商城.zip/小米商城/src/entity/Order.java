package entity;

public class Order {
	private int order1_id;
	private String order1_item_name;
	private int order1_item_price;
	private int order1_item_num;
	private int order1_item_totalprice;
	private String order1_username;
	public int getOrder_id() {
		return order1_id;
	}
	public void setOrder_id(int orderId) {
		order1_id = orderId;
	}
	public String getOrder_item_name() {
		return order1_item_name;
	}
	public void setOrder_item_name(String orderItemName) {
		order1_item_name = orderItemName;
	}
	public double getOrder_item_price() {
		return order1_item_price;
	}
	public void setOrder_item_price(int orderItemPrice) {
		order1_item_price = orderItemPrice;
	}
	public int getOrder_item_num() {
		return order1_item_num;
	}
	public void setOrder_item_num(int orderItemNum) {
		order1_item_num = orderItemNum;
	}
	public double getOrder_item_totalprice() {
		return order1_item_totalprice;
	}
	public void setOrder_item_totalprice(int orderItemTotalprice) {
		order1_item_totalprice = orderItemTotalprice;
	}
	public String getOrder_username() {
		return order1_username;
	}
	public void setOrder_username(String orderUsername) {
		order1_username = orderUsername;
	}
	
	

}
