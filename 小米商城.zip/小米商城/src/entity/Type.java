package entity;

public class Type {
	private int t_id;
	private String t_name;
	private double t_price;
	private String t_disc;
	private String t_img;
	public String getT_img() {
		return t_img;
	}
	public void setT_img(String tImg) {
		t_img = tImg;
	}
	public int getT_id() {
		return t_id;
	}
	public void setT_id(int tId) {
		t_id = tId;
	}
	public String getT_name() {
		return t_name;
	}
	public void setT_name(String tName) {
		t_name = tName;
	}
	public double getT_price() {
		return t_price;
	}
	public void setT_price(double tPrice) {
		t_price = tPrice;
	}
	public String getT_disc() {
		return t_disc;
	}
	public void setT_disc(String tDisc) {
		t_disc = tDisc;
	}
}
