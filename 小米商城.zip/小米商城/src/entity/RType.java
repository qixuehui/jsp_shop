package entity;

public class RType {
	 private int rt_id;
	 private String rt_name;
	public int getRt_id() {
		return rt_id;
	}
	public void setRt_id(int rtId) {
		rt_id = rtId;
	}
	public String getRt_name() {
		return rt_name;
	}
	public void setRt_name(String rtName) {
		rt_name = rtName;
	}
	 
}
