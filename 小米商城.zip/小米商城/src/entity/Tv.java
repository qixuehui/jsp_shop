package entity;

public class Tv {
	private int tv_id;
	private String tv_name;
	private double tv_price;
	private String tv_disc;
	private String tv_img;
	private int tv_num;
	public int getTv_num() {
		return tv_num;
	}
	public void setTv_num(int tv_num) {
		this.tv_num = tv_num;
	}
	public int getTv_id() {
		return tv_id;
	}
	public void setTv_id(int tv_id) {
		this.tv_id = tv_id;
	}
	public String getTv_name() {
		return tv_name;
	}
	public void setTv_name(String tv_name) {
		this.tv_name = tv_name;
	}
	public double getTv_price() {
		return tv_price;
	}
	public void setTv_price(double tv_price) {
		this.tv_price = tv_price;
	}
	public String getTv_disc() {
		return tv_disc;
	}
	public void setTv_disc(String tv_disc) {
		this.tv_disc = tv_disc;
	}
	public String getTv_img() {
		return tv_img;
	}
	public void setTv_img(String tv_img) {
		this.tv_img = tv_img;
	}

}
