package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCTest {

public static void main(String[] args){
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/item","root","");

			Statement statement=conn.createStatement();
		    String sql="select * from user";
		    ResultSet rs=statement.executeQuery(sql);
		   
		    while(rs.next()){
		    	
		    	System.out.print(rs.getInt("id")+" ");
		    	System.out.print(rs.getString("username")+" ");
		    	System.out.print(rs.getString("password")+" ");
		    	System.out.print(rs.getString("mobile")+" ");
		    	System.out.println(rs.getString("mailbox"));
		    }
		    rs.close();
		    statement.close();
		    conn.close();
		    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
