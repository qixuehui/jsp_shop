package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCUtil {
//�������·��
private static final String DRIVER="com.mysql.jdbc.Driver";
//���ݿ�ĵ�ַ(���ݿ⴫�ص��û���Ϣʱ���뷽ʽͳһ��utf-8)
private static final String URL="jdbc:mysql://localhost:3306/item?characterEncoding=UTF-8";
private static final String USER="root";
private static final String PASSWORD="";
private static Connection conn=null;
private static Statement statement=null;

static{
//��������
	try {
		Class.forName(DRIVER);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
//������ݿ�����
public static Connection getConn(){
	try {
		conn=DriverManager.getConnection(URL,USER,PASSWORD);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return conn;
}
//���ִ��sql����statement
public static Statement getStatement(){
try {
	statement=getConn().createStatement();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}	
return statement;
}

public static void closeAll(ResultSet rs,Statement st,Connection conn){
	try {
		if(rs!=null){
		rs.close();
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			if(st!=null){
			st.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn!=null){
				conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
public static void main(String args[]){
	System.out.println(getStatement());
}
}
