package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.JDBCUtil;

public class LoginServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
    request.setCharacterEncoding("UTF-8");
    String username=request.getParameter("username");
    String password=request.getParameter("password");
    String role=request.getParameter("role");
    //��ȡִ��sql�Ķ���
    Statement st=JDBCUtil.getStatement();
	String sql="select * from user where username='"+username+"' and password='"+password+"' and role='"+role+"'"; 
	try {
		ResultSet rs=st.executeQuery(sql);
		if(rs.next()){
			//���û��洢��session��,�����ڹ���������
			HttpSession session=request.getSession();
			session.setAttribute("user", username);
			System.out.println(session.getAttribute("user"));
			session.setMaxInactiveInterval(30);
			//֧�����ģ�Ҫ��username���б��룬���н���
			username=URLEncoder.encode(username,"UTF-8");	
			if(role.equals("0")){
		//role=0��������ͨ�û���Ϣ����������ݿ��в�ѯ���û���Ϣ�����ʾ��֤�ɹ����������ɹ�ҳ��,(���÷���������ת��ʽ)
		response.sendRedirect("../index.jsp");	
		}else if(role.equals("1")){	
	       response.sendRedirect("../main.jsp");
		}
			
		}else{
	  response.sendRedirect("../login.jsp?flag=fail");
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(sql);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
