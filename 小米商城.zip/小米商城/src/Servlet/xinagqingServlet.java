package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ITypeDao;
import dao.IUserDao;
import dao.TypeDao;
import dao.UserDao;
import entity.Product;

public class xinagqingServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public xinagqingServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//
			request.setCharacterEncoding("UTF-8");
			String username=request.getParameter("username");
			String user=new String(username.getBytes("ISO-8859-1"),"UTF-8");
			Product product = new Product();
			if(Integer.parseInt(request.getParameter("name")) == 1){
				product.setItemname("С���ֻ�6GB�ڴ�64GB");
				product.setNum(Integer.parseInt(request.getParameter("num")));
				System.out.println(Integer.parseInt(request.getParameter("num")));
			}
			product.setItemprice(Integer.parseInt(request.getParameter("price")));
			System.out.println(666);
			product.setUsername(user);
			System.out.println(product.getUsername());
			IUserDao userDao = new UserDao();
			userDao.AddProduct(product);
			response.sendRedirect("../xiangqing.jsp");
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
