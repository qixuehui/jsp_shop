package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.IProduct3Dao;
import dao.ITvDao;
import dao.ITypeDao;
import dao.IUserDao;
import dao.Product3Dao;
import dao.TvDao;
import dao.TypeDao;
import dao.UserDao;

import entity.Product3;
import entity.Tv;
import entity.Type;
import entity.User;
import entity.XiaoMi;

public class DeleteTypeServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public DeleteTypeServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
     request.setCharacterEncoding("UTF-8");
     int flag = Integer.parseInt(request.getParameter("flag"));
     if(flag==1){
    	 int id= Integer.parseInt(request.getParameter("select_cust_id"));
    	 IUserDao userdao = new UserDao();
    	 userdao.deleteUser(id);
     }
     else if(flag==2){
    	 Type type=new Type();
         //���յ�ǰ��ҳ���id
         type.setT_id(Integer.parseInt(request.getParameter("radio_id")));
         //����id
         ITypeDao typeDao=new TypeDao();
         Type typeDB = typeDao.findTypeById(type.getT_id());
         //����鵽���ݿ���id����յ���id�����ɾ��
         if(typeDB.getT_id() == type.getT_id()){
        	 typeDao.deleteType(type);
        	 System.out.println("���ҳɹ���");
    	 	//response.sendRedirect("../product/type_list");
        	// request.getRequestDispatcher("../product/type_list").forward(request, response);
    	}else{
    		//response.sendRedirect("../product/type_list");
    		System.out.println("����ʧ�ܣ�");
    	}	 
     }else if(flag==3){
    	 Product3 p3=new Product3();
    	 p3.setLaptop_id(Integer.parseInt(request.getParameter("laptop_radio_id")));
    	 IProduct3Dao p3Dao=new Product3Dao();
    	 Product3 p3DB= p3Dao.findProduct3ById(p3.getLaptop_id());
    	 if(p3DB.getLaptop_id()==p3.getLaptop_id()){
    		 p3Dao.deleteProduct3(p3);
    		 
    	}
    	//�޸ĺ��Զ���ת���޸ĺ��ҳ��
     	request.getRequestDispatcher("../product/laptop_list.jsp").forward(request, response);
     }else if(flag==4){
    	 Tv tv=new Tv();
    	 tv.setTv_id(Integer.parseInt(request.getParameter("radio_id")));
    	 ITvDao tvDao=new TvDao();
    	 Tv tvDB=tvDao.findTvById(tv.getTv_id());
    	 tvDao.deleteTV(tv);
    	//�޸ĺ��Զ���ת���޸ĺ��ҳ��
     	request.getRequestDispatcher("../tv.jsp").forward(request, response);
     }else if(flag==5){
    	 XiaoMi xiaomi=new XiaoMi();
    	 xiaomi.setId(Integer.parseInt(request.getParameter("radio_id")));
    	 ITypeDao typeDao=new TypeDao();
    	 XiaoMi xiaomiDB=typeDao.findXiaoMiById(xiaomi.getId());
    	 typeDao.deleteXiaoMi(xiaomi);
    	//�޸ĺ��Զ���ת���޸ĺ��ҳ��
     	request.getRequestDispatcher("../list.jsp").forward(request, response);
     }
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
