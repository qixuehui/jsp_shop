package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.IProduct3Dao;
import dao.ITvDao;
import dao.ITypeDao;
import dao.IUserDao;
import dao.Product3Dao;
import dao.TvDao;
import dao.TypeDao;
import dao.UserDao;

import entity.Product3;
import entity.Tv;
import entity.Type;
import entity.User;

public class ModifyServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ModifyServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        int flag = Integer.parseInt(request.getParameter("flag"));
        if(flag==1){
        	User user = new User();
        	user.setId(Integer.parseInt(request.getParameter("id")));
        	user.setUsername(request.getParameter("user_username-name"));
        	user.setPassword(request.getParameter("user_password_name"));
        	user.setMobile(request.getParameter("user_mobile_name"));
            user.setMailbox(request.getParameter("user_mailbox_name"));
            user.setRole(Integer.parseInt(request.getParameter("card_type_id")));
            IUserDao userdao = new UserDao();
            userdao.modifyUser(user);
        }else if(flag==2){//�����޸���Ʒ��������Ϣ
        	//��ǰ��ҳ�洫�����޸Ĳ���
    		Type type=new Type();
    		type.setT_id(Integer.parseInt(request.getParameter("id")));
    		//System.out.println(type.getT_id());
    		type.setT_name(request.getParameter("name"));	
    		type.setT_price(Double.parseDouble(request.getParameter("price")));
    		type.setT_disc(request.getParameter("disc"));
    		type.setT_img(request.getParameter("img"));
    		 
    		ITypeDao typeDao=new TypeDao();
    		Type typeDB=typeDao.findTypeById(type.getT_id());
    		
    		//System.out.println(type.getT_id());
    		//System.out.println(typeDB.getT_id());
    		
    		if(typeDB.getT_id()==type.getT_id()){
    			typeDao.modifyType(type);
    			System.out.println("success");
    		}else{
    			System.out.println("fail");
    		}
    		
    		//�޸ĺ��Զ���ת���޸ĺ��ҳ��
        	request.getRequestDispatcher("../product/type_list.jsp").forward(request, response);
        }else if(flag==3){
        	Product3 p=new Product3();
        	p.setLaptop_id(Integer.parseInt(request.getParameter("id")));
        	p.setLaptop_name(request.getParameter("name"));
        	p.setLaptop_price(Double.parseDouble(request.getParameter("price")));
        	p.setLaptop_disc(request.getParameter("disc"));
        	p.setLaptop_img(request.getParameter("img"));
        	IProduct3Dao product3Dao=new Product3Dao();
        	Product3 p3DB=product3Dao.findProduct3ById(p.getLaptop_id());
        	if(p3DB.getLaptop_id()==p.getLaptop_id()){
        		product3Dao.modifyProduct3(p);
        		System.out.println("success");
        	}else{
        		System.out.println("fail");
        	}
        	//�޸ĺ��Զ���ת���޸ĺ��ҳ��
        	request.getRequestDispatcher("../product/laptop_list.jsp").forward(request, response);
        }else if(flag==4){//���޸���Ʒ��ͼƬ
        	Type type=new Type();
        	type.setT_img(request.getParameter("img"));
        	ITypeDao typeDao=new TypeDao();
    		Type typeDB=typeDao.findTypeById(type.getT_id());
    		if(typeDB.getT_id()==type.getT_id()){
    			typeDao.modifyType(type);
    			System.out.println("success");
    		}else{
    			System.out.println("fail");
    		}
    		//�޸ĺ��Զ���ת���޸ĺ��ҳ��
        	request.getRequestDispatcher("../product/type_list.jsp").forward(request, response);
        }else if(flag==5){//�޸�TV��������Ϣ
        	Tv tv=new Tv();
        	tv.setTv_id(Integer.parseInt(request.getParameter("id")));
        	//System.out.println(Integer.parseInt(request.getParameter("id")));
        	tv.setTv_name(request.getParameter("name"));
        	tv.setTv_price(Double.parseDouble(request.getParameter("price")));
        	tv.setTv_disc(request.getParameter("disc"));
        	tv.setTv_img(request.getParameter("img"));
        	//tv.setTv_num(Integer.parseInt(request.getParameter("num")));
        	ITvDao tvDao=new TvDao();
            Tv tvDB=tvDao.findTvById(tv.getTv_id());
    		if(tvDB.getTv_id()==tv.getTv_id()){
    			tvDao.modifyTV(tv);
    			System.out.println("success");
    		}else{
    			System.out.println("fail");
    		}
    		//�޸ĺ��Զ���ת���޸ĺ��ҳ��
        	request.getRequestDispatcher("../tv.jsp").forward(request, response);
        }
			
			
		}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
