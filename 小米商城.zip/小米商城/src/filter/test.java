package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class test implements Filter{

	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		// TODO Auto-generated method stub
        HttpServletRequest request=(HttpServletRequest)arg0;
        HttpServletResponse response=(HttpServletResponse)arg1;
        HttpSession session=request.getSession();
        // session.setMaxInactiveInterval(20);
        String uri=request.getRequestURI();
        //uri����ȡ����·��
        String path=uri.substring(uri.lastIndexOf("/")+1);
        if(session.getAttribute("user")!=null||path.equals("login.jsp")||path.equals("register.jsp")){
            arg2.doFilter(arg0, arg1);
        }else{
            //δ��¼�򷵻ص�¼ҳ��
            response.sendRedirect("/Item/login.jsp");
        }
    }
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
